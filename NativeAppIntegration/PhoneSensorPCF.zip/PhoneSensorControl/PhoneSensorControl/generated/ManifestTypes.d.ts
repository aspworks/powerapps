/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    ActivateNFC: ComponentFramework.PropertyTypes.StringProperty;
    DataToPhone: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    ActivateNFC?: string;
    DataToPhone?: string;
    OtherData?: string;
    NFCMessage?: string;
}
